"""Dashboard HTTP API package."""
